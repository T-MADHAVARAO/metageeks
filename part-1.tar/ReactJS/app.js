import React, { Component } from "react";

class BlogPostList extends Component {
  constructor(props) {
    super(props);

    this.state = {
      posts: [],
      loading: true,
    };
  }

  componentDidMount() {
    // Simulating a fetch operation
    this.fetchPosts();
  }

  fetchPosts = async () => {
    try {
      // Set loading to true while fetching
      this.setState({ loading: true });

      // Simulating an API call to fetch blog posts
      const response = await fetch(
        "https://jsonplaceholder.typicode.com/posts"
      );
      const data = await response.json();

      // Set the fetched posts and update loading state
      this.setState({ posts: data, loading: false });
    } catch (error) {
      console.error("Error fetching posts:", error);
      this.setState({ loading: false });
    }
  };

  // Function to handle viewing the full post (you can define this function based on your application logic)
  viewFullPost = (postId) => {
    // Add logic to navigate to the full post view, e.g., using React Router or other navigation methods.
    console.log(`Viewing full post with ID ${postId}`);
  };

  render() {
    const { posts, loading } = this.state;

    return (
      <div>
        <h2>Blog Posts</h2>
        {loading ? (
          <p>Loading...</p>
        ) : (
          <ul>
            {posts.map((post) => (
              <li key={post.id}>
                <h3>{post.title}</h3>
                <p>Author: {post.userId}</p>
                <button onClick={() => this.viewFullPost(post.id)}>
                  View Full Post
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    );
  }
}

export default BlogPostList;

const express = require("express");
const { open } = require("sqlite");
const sqlite3 = require("sqlite3");
const path = require("path");
const app = express();
const dbPath = path.join(__dirname, "dbFileName.db");

//initializing DataBase and Server

const initializingDbAndSerer = async () => {
  try {
    // Connect to SQLite database

    let db = await open({ filename: dbPath, driver: sqlite3.Database });

    // Start the Express server

    app.listen(PORT, () => {
      console.log(`Server is running on http://localhost:${PORT}`);
    });
  } catch (err) {
    console.log(`Db Error: ${error}`);
    process.exit(1);
  }
};

initializingDbAndSerer(); //calling

// Define a route to retrieve a list of posts

app.get("/posts", async (req, res) => {
  // Query the database to get all posts

  await db.all("SELECT * FROM Posts", (err, posts) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: "Internal Server Error" });
    } else {
      res.json(posts);
    }
  });
});

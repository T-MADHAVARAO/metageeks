const logRequest = (req, res, next) => {
  const timestamp = new Date().toUTCString();
  const url = req.originalUrl;

  console.log(`[${timestamp}] ${url}`);

  next();
};

module.exports = logRequest;

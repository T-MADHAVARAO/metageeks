const express = require("express");
const logRequest = require("./timestamp");

const app = express();

// Use the logRequest middleware for every incoming request

app.use(logRequest);

// Your other routes and middleware go here

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

const axios = require("axios");

const fetchUsersWithPosts = async () => {
  try {
    // Fetch users from JSONPlaceholder API
    const usersResponse = await axios.get(
      "https://jsonplaceholder.typicode.com/users"
    );
    const users = usersResponse.data;

    // Fetch posts for each user
    const usersWithPosts = await Promise.all(
      users.map(async (user) => {
        const postsResponse = await axios.get(
          `https://jsonplaceholder.typicode.com/posts?userId=${user.id}`
        );
        const posts = postsResponse.data;

        return {
          ...user,
          posts,
        };
      })
    );

    return usersWithPosts;
  } catch (error) {
    console.error("Error fetching data:", error.message);
    throw error;
  }
};

// Example usage
fetchUsersWithPosts()
  .then((usersWithPosts) => {
    console.log(usersWithPosts);
  })
  .catch((error) => {
    // Handle errors
    console.log(`Error: ${error.message}`);
  });

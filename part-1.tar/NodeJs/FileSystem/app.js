const fs = require("fs");

// Read the input JSON file
const readInputFile = (filePath) => {
  try {
    const data = fs.readFileSync(filePath, "utf8");
    return JSON.parse(data);
  } catch (error) {
    console.error("Error reading input file:", error.message);
    process.exit(1);
  }
};

// Write the output JSON file
const writeOutputFile = (filePath, data) => {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    console.log(`Modified data written to ${filePath}`);
  } catch (error) {
    console.error("Error writing output file:", error.message);
    process.exit(1);
  }
};

// Manipulate the user data to include the total number of posts each user has created
const manipulateUserData = (userData) => {
  return userData.map((user) => {
    const totalPosts = user.posts.length;
    return {
      ...user,
      totalPosts,
    };
  });
};

// Specify the input and output file paths
const inputFile = "input.json";
const outputFile = "output.json";

// Read the input JSON file
const userData = readInputFile(inputFile);

// Manipulate the user data
const modifiedUserData = manipulateUserData(userData);

// Write the modified data to the output JSON file
writeOutputFile(outputFile, modifiedUserData);
